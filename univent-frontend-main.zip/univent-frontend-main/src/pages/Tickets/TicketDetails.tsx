
const TicketDetails = () => {
  return <div>TicketDetails</div>;
};

export default TicketDetails;
