
const TicketsList = () => {
  return <div>TicketsList</div>;
};

export default TicketsList;
