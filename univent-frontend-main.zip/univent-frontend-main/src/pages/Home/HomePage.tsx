import EventsList from '../Events/EventsList';

export default function HomePage() {
  return <EventsList />;
}
