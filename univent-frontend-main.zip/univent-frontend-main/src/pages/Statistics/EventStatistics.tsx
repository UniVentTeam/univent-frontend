
const EventStatistics = () => {
  return <div>EventStatistics</div>;
};

export default EventStatistics;
