
const EventsRaports = () => {
  return <div>EventsRaports</div>;
};

export default EventsRaports;
