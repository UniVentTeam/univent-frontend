
const EventDetails = () => {
  return <div>EventDetails</div>;
};

export default EventDetails;
