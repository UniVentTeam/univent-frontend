
const OrganizationEvents = () => {
  return <div>OrganizationEvents</div>;
};

export default OrganizationEvents;
